import React from "react";
import "./styles.css";

const ComingSoon = () => {
  return (
    <div className="comming-soon-main">
      <div className="text">Coming soon</div>
    </div>
  );
};

export default ComingSoon;
