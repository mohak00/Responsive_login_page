export function usersAction(input) {
  return {
    type: "ADD_USER",
    payload: input,
  };
}
